public class Find {
    public static void main(String args[])
    {
        int[] Array = {1, 1, 10, 32, 41 };
        int X = 42;
        //calling the function
        getPairsCount(Array, X);
    }

    // Prints number of pairs in Array[0..n-1] with sum equal
    // to 'X'
    public static void getPairsCount(int[] array, int x)
    {
        // Initialize result
        int count = 0;

        // Consider all possible pairs and check their sums
        for (int i = 0; i < array.length; i++)
            for (int j = i + 1; j < array.length; j++)
                if ((array[i] + array[j]) == x)
                    count++;
        System.out.println("****************************************");
        System.out.println("Answer : Count of pairs is :: "+ count);
        System.out.println("****************************************");
    }
}